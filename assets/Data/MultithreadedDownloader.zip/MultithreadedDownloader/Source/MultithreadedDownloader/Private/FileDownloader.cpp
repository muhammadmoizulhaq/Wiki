// Fill out your copyright notice in the Description page of Project Settings.

#include "FileDownloader.h"
#include "MultithreadedDownloaderDefines.h"

#include "Misc/Paths.h"
#include "HAL/FileManager.h"
#include "HAL/PlatformFileManager.h"
#include "GenericPlatform/GenericPlatformFile.h"

UFileDownloader::UFileDownloader()
	: FileUrl(TEXT(""))
	, FileSavePath(TEXT(""))
	, bIsMultithrreaded()
	, bRunThread()
{
	Thread = FRunnableThread::Create(this, TEXT("File Downloader"));
}

UFileDownloader::~UFileDownloader()
{
	if (Thread)
	{
		Thread->Kill();
		delete Thread;
	}
}


bool UFileDownloader::Init()
{
	return false;
}

uint32 UFileDownloader::Run()
{
	while (bRunThread)
	{
		if (bIsMultithrreaded)
		{
			DownloadFile(FileUrl, FileSavePath, bIsMultithrreaded);
			FPlatformProcess::Sleep(1.0f);
			bIsMultithrreaded = false;
			FPlatformProcess::Sleep(0.0f);
		}
	}
	return 0;
}

void UFileDownloader::Stop()
{
	bRunThread = false;
}

UFileDownloader* UFileDownloader::MakeDownloader()
{
	UFileDownloader* Downloader = NewObject<UFileDownloader>();
	return Downloader;
}

void UFileDownloader::Download(const FString& URL, FString SavePath)
{
	FString MyPathPart;
	FString MyFilenamePart;
	FString MyExtensionPart;
	FPaths::Split(URL, MyPathPart, MyFilenamePart, MyExtensionPart);
	UE_LOG(LogMultithreadedDownloader, Warning, TEXT("Downloading {%s} to {%s} the extension of file is {%s}"), *MyFilenamePart, *SavePath, *MyExtensionPart);
	FString MySavePath = SavePath + MyFilenamePart + "." + MyExtensionPart;
	if (this->IsValidLowLevel())
	{
		DownloadFile(URL, MySavePath, true);
	}
}

UFileDownloader* UFileDownloader::DownloadFile(const FString& Url, FString SavePath, bool bMultithreaded)
{
	UE_LOG(LogTemp, Log, TEXT("DLC Downloader is Running"));
	FileUrl = Url;
	FileSavePath = SavePath;
	bIsMultithrreaded = bMultithreaded;
	if (FPaths::FileExists(FileSavePath) != true)
	{
		TSharedRef<IHttpRequest, ESPMode::ThreadSafe> HttpRequest = FHttpModule::Get().CreateRequest();
		HttpRequest->SetVerb("GET");
		HttpRequest->SetURL(Url);
		HttpRequest->OnProcessRequestComplete().BindUObject(this, &UFileDownloader::OnReady);
		HttpRequest->OnRequestProgress().BindUObject(this, &UFileDownloader::OnProgress_Internal);
		// Execute the request
		HttpRequest->ProcessRequest();
		AddToRoot();
	}
	else
	{
		OnResult.Broadcast(EDownloadResult::FILEEXIST);
	}
	if (bMultithreaded)
	{
		delete Worker;
	}
	return this;
}

void UFileDownloader::OnReady(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
	RemoveFromRoot();
	Request->OnProcessRequestComplete().Unbind();
	if (Response.IsValid() && EHttpResponseCodes::IsOk(Response->GetResponseCode()))
	{
		IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();

		FString Path, Name, Extension;
		//FPaths::Split(FileSavePath, Path, Filename, Extension);
		if (FPaths::FileExists(FileSavePath) == true)
		{
			OnResult.Broadcast(EDownloadResult::FILEEXIST);
		}
		else if (FPaths::FileExists(FileSavePath) == false)
		{
			FPaths::Split(FileSavePath, Path, Name, Extension);
		}
		else
		{
			OnResult.Broadcast(EDownloadResult::DOWNLOADFAILED);
		}
		if (!PlatformFile.DirectoryExists(*Path))
		{
			if (!PlatformFile.CreateDirectoryTree(*Path))
			{
				OnResult.Broadcast(EDownloadResult::DIRECTORYCREATIONFAILED);
				return;
			}
		}
		IFileHandle* FileHandle = PlatformFile.OpenWrite(*FileSavePath);
		if (FileHandle)
		{
			FileHandle->Write(Response->GetContent().GetData(), Response->GetContentLength());
			delete FileHandle;
			OnResult.Broadcast(EDownloadResult::SUCCESS);
		}
		else
		{
			OnResult.Broadcast(EDownloadResult::SAVEFAILED);
		}
	}
	else
	{
		UE_LOG(LogMultithreadedDownloader, Warning, TEXT("WAS SUCCESSFUL: %s"), (bWasSuccessful ? TEXT("True") : TEXT("False")));
		OnResult.Broadcast(EDownloadResult::DOWNLOADFAILED);
	}
}

void UFileDownloader::OnProgress_Internal(FHttpRequestPtr Request, int32 BytesSent, int32 BytesReceived)
{
	FHttpResponsePtr HttpResponse = Request->GetResponse();
	int32 FullSize = 0;
	if (HttpResponse.IsValid())
	{
		FullSize = HttpResponse->GetContentLength();
		OnDownload(BytesReceived, FullSize);
		OnProgress.Broadcast(BytesSent, BytesReceived, FullSize);
	}
}

void UFileDownloader::OnDownload(int32 BytesReceived, int32 FileSize)
{
	if (FileSize <= 0)
	{
		UE_LOG(LogTemp, Error, TEXT("FileSize <=0 in DLC Downloader "));
		return;
	}
	float percentage = (BytesReceived * 100.0) / FileSize;
	OnDownloadInfo.Broadcast(percentage);
}