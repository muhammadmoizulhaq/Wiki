// Copyright Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;

public class MultithreadedDownloader : ModuleRules
{
	public MultithreadedDownloader(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(
			new string[]
			{
                "CoreUObject",
				"Engine",
				"Core",
				"HTTP",
			}
		);
	}
}
