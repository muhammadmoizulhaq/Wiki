// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Http.h"
#include "HAL/Runnable.h"
#include "HAL/RunnableThread.h"
#include "HAL/ThreadSafeBool.h"
#include "FileDownloader.generated.h"

/** Possible results from a download request */
UENUM(BlueprintType, Category = "Downloader")
enum  class EDownloadResult : uint8
{
	SUCCESS UMETA(DisplayName = "Success"),
	DOWNLOADFAILED UMETA(DisplayName = "Download Failed"),
	SAVEFAILED UMETA(DisplayName = "Save Failed"),
	DIRECTORYCREATIONFAILED UMETA(DisplayName = "Directory Creation Failed"),
	INVLAIDURL UMETA(DisplayName = "Invalid URL"),
	INVALIDSAVEPATH UMETA(DisplayName = "Invalid Save Path"),
	FILEEXIST UMETA(DisplayName = "File Exist"),
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnResult, const EDownloadResult, Result);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnProgress, const int32, BytesSent, const int32, BytesReceived, const int32, ContentLength);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnDownloaded, const float, Downloaded);

/**
* Library for downloading, Downloads a file and saves it to permanent storage
*/
UCLASS(BlueprintType, Category = "Downloader")
class MULTITHREADEDDOWNLOADER_API UFileDownloader : public UObject, public FRunnable
{
	GENERATED_BODY()

public:
	UPROPERTY(BlueprintAssignable, Category = "Downloader")
	FOnResult OnResult;

	UPROPERTY(BlueprintAssignable, Category = "Downloader")
	FOnDownloaded OnDownloadInfo;

	UPROPERTY(BlueprintAssignable, Category = "Downloader")
	FOnProgress OnProgress;

	UPROPERTY(BlueprintReadOnly, Category = "Downloader")
	FString FileUrl = "";

	UPROPERTY(BlueprintReadOnly, Category = "Downloader")
	FString FileSavePath = "";

	UPROPERTY(BlueprintReadOnly, Category = "Downloader")
	bool bIsMultithrreaded = false;

	UFileDownloader();
	virtual ~UFileDownloader() override;

	/**
	* Instantiates a Downloader object, starts downloading and saves it when done.
	*
	* @return The Downloader object. Bind to it's OnResult event to know when it's done downloading also bind to OnDownload event to know the download progress.
	*/
	UFUNCTION(BlueprintCallable, Meta = (DisplayName = "Create Downloader"), Category = "Downloader")
	static UFileDownloader* MakeDownloader();

	// Overriden from FRunnable
	// Do not call these functions youself, that will happen automatically
	bool Init() override; // Do your setup here, allocate memory, ect.
	uint32 Run() override; // Main data processing happens here
	void Stop() override; // Clean up any memory you allocated here

	/**
	* Starts downloading a file and saves it when done. Bind to the OnResult
	* event to know when the download is done (preferrably, before calling this function).
	*
	* @param Url		The file Url to be downloaded.
	* @param SavePath	The absolute path and file name to save the downloaded file.
	* @return Returns itself.
	*/
	UFUNCTION(BlueprintCallable, Category = "Downloader")
	void Download(const FString& URL, FString SavePath);
private:
	UFileDownloader* DownloadFile(const FString& Url, FString SavePath, bool bMulti);
	void OnReady(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful);
	void OnProgress_Internal(FHttpRequestPtr Request, int32 BytesSent, int32 BytesReceived);
	void OnDownload(int32 BytesReceived, int32 FileSize);

	UFileDownloader* Worker;

	// Thread handle. Control the thread using this, with operators like Kill and Suspend
	FRunnableThread* Thread;

	// Used to know when the thread should exit, changed in Stop(), read in Run()
	bool bRunThread;
};